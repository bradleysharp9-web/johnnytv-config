# Stream Player — a white-label Xtream portal player for Android & Android TV

A complete, buildable Android app that signs in to an Xtream Codes portal
(server + username + password), lists Live TV and Movies by category, lets you
search, and plays streams with ExoPlayer. One APK works on phones, tablets and
Android TV / Nvidia Shield (full D-pad navigation).

You own this source. Rebrand it as many times as you like — no licence, no
per-app fee, no third-party build server, and you hold your own signing key.

---

## Part 1 — Get an APK in about 10 minutes (no software to install)

You never have to open or edit a single line of code for this part.

### Step 1 — Make a GitHub account
Go to **github.com** and sign up. It's free.

### Step 2 — Make a new repository
1. Click the **+** in the top-right → **New repository**.
2. Name it anything (e.g. `my-player`).
3. Choose **Private**.
4. Click **Create repository**.

### Step 3 — Upload this project
1. On the new empty repo page, click **uploading an existing file**.
2. Unzip the project folder on your computer.
3. Select **everything inside** the `streamplayer` folder (not the folder
   itself) and drag it into the browser window.
4. Wait for the file list to finish, then click **Commit changes**.

> **If the `.github` folder doesn't upload** (some browsers skip folders
> starting with a dot), do this instead: click the **Actions** tab →
> **set up a workflow yourself** → delete everything in the editor → paste the
> contents of `.github/workflows/build-apk.yml` from the project → **Commit changes**.
> That single step both creates the file and starts the first build.

### Step 4 — Download your APK
1. Click the **Actions** tab.
2. Click the run at the top of the list (it takes ~3 minutes; a green tick
   means it worked).
3. Scroll to the bottom to **Artifacts** → click **app-apk** to download.
4. Inside the zip is `app-debug.apk`. That's your app.

### Step 5 — Install it
- **On a phone:** copy the APK across, tap it, allow "install from unknown
  sources" when prompted.
- **On an Nvidia Shield / Android TV:** install *Downloader* (by AFTVnews) or
  *Send Files to TV* from the Play Store on the Shield, move the APK over, and
  open it. Enable **Settings → Device Preferences → Security → Unknown sources**
  first.

Every time you change something and commit, GitHub builds a fresh APK
automatically. Downloading the new one from **Actions** is the whole workflow.

---

## Part 2 — White-labelling it (the five things you change per client)

### 1. App name
`app/src/main/res/values/strings.xml` → the `app_name` line.

### 2. Colours
`app/src/main/res/values/colors.xml` → the five `brand_*` / `bg_*` values at the
top. Everything in the app is themed from those, so changing them restyles the
whole app.

### 3. Icon and TV banner
Replace the PNGs in `app/src/main/res/mipmap-*/` (the launcher icon, five
sizes) and `app/src/main/res/drawable-nodpi/tv_banner.png` (must stay exactly
320×180 — that's the tile on the Android TV home screen).

### 4. Package ID — important
`app/build.gradle.kts` → change **both** `namespace` and `applicationId` from
`com.johnnytv.player` to something unique, e.g. `com.yourbrand.player`.
Two apps with the same applicationId can't be installed side by side, so each
client build needs its own.

*(If you change it, also rename the folder
`app/src/main/java/com/example/streamplayer` to match, and update the
`package com.johnnytv.player` line at the top of each `.kt` file. If that
sounds fiddly, leave it — the app works fine as-is; you only need a unique ID
when you're shipping more than one build.)*

### 5. Portal behaviour
`app/src/main/java/com/example/streamplayer/Config.kt`:

| Setting | Effect |
|---|---|
| `DEFAULT_SERVER = ""` | Leave blank and the user types the portal address. Set it to pre-fill the field. |
| `LOCK_SERVER = false` | Set `true` to hide the server field completely — the app only ever talks to `DEFAULT_SERVER`. This is the usual white-label setup. |
| `PRESET_USERNAME` / `PRESET_PASSWORD` | Set both (plus `DEFAULT_SERVER`) and the login screen is skipped entirely — the app opens straight into the channel list. |
| `LIVE_CONTAINERS` | Which stream formats to try, in order. Default `m3u8` then `ts`, which covers nearly every panel. |

---

## What's in the app

| File | What it does |
|---|---|
| `Config.kt` | Every white-label setting, in one place |
| `Prefs.kt` | Remembers the signed-in portal on the device |
| `XtreamClient.kt` | Talks to `player_api.php` — login, categories, streams, URL building |
| `LoginActivity.kt` | The sign-in screen |
| `MainActivity.kt` | Live/Movies tabs, category column, channel list, search |
| `PlayerActivity.kt` | Fullscreen ExoPlayer with automatic `.m3u8` → `.ts` fallback |
| `Adapters.kt` | The two list views, focus-aware so a TV remote works |

**Address formats accepted at sign-in:** `http://portal.com:8080`,
`portal.com:8080`, or a pasted `.../player_api.php` URL — the app cleans it up.

---

## Not included yet (all addable on this base)

EPG / TV guide, series & episodes, catch-up, favourites, parental PIN,
picture-in-picture, channel logos, multi-screen. The API client already has the
plumbing for series and EPG — they're extra `action=` calls on the same endpoint.

## Notes

- The build produces a **debug-signed** APK. It installs and runs normally on
  any device. If you later want to publish on the Play Store you'll need a
  release keystore — ask and it's a 15-minute addition to the workflow.
- `usesCleartextTraffic` is enabled because most Xtream panels serve over plain
  `http`. If your portal is `https`-only you can turn it off in the manifest.
- The app is a player. Whether the content behind a given portal is licensed is
  down to the provider, not the app.
