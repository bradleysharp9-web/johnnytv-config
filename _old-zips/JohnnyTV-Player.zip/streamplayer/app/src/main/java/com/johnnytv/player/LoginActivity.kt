package com.johnnytv.player

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var serverInput: EditText
    private lateinit var usernameInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var signInButton: Button
    private lateinit var progress: ProgressBar
    private lateinit var statusLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        // Already signed in - straight to the channel list.
        if (prefs.isLoggedIn) {
            goToMain()
            return
        }

        setContentView(R.layout.activity_login)

        serverInput = findViewById(R.id.serverInput)
        usernameInput = findViewById(R.id.usernameInput)
        passwordInput = findViewById(R.id.passwordInput)
        signInButton = findViewById(R.id.signInButton)
        progress = findViewById(R.id.loginProgress)
        statusLabel = findViewById(R.id.loginStatus)

        if (Config.DEFAULT_SERVER.isNotBlank()) {
            serverInput.setText(Config.DEFAULT_SERVER)
        }
        if (Config.LOCK_SERVER) {
            serverInput.visibility = View.GONE
        }

        signInButton.setOnClickListener { attemptSignIn() }

        // Fully pre-loaded build: sign in without asking for anything.
        if (Config.PRESET_USERNAME.isNotBlank() && Config.PRESET_PASSWORD.isNotBlank()) {
            usernameInput.setText(Config.PRESET_USERNAME)
            passwordInput.setText(Config.PRESET_PASSWORD)
            attemptSignIn()
        }
    }

    private fun attemptSignIn() {
        val server = if (Config.LOCK_SERVER) Config.DEFAULT_SERVER else serverInput.text.toString()
        val username = usernameInput.text.toString().trim()
        val password = passwordInput.text.toString().trim()

        if (server.isBlank() || username.isBlank() || password.isBlank()) {
            statusLabel.text = getString(R.string.fill_all_fields)
            return
        }

        setBusy(true)
        statusLabel.text = getString(R.string.signing_in)

        lifecycleScope.launch {
            val client = XtreamClient(server, username, password)
            val result = runCatching {
                withContext(Dispatchers.IO) { client.login() }
            }
            setBusy(false)
            result.onSuccess { accountStatus ->
                prefs.save(client.server, username, password)
                statusLabel.text = accountStatus
                goToMain()
            }.onFailure { error ->
                statusLabel.text = error.message ?: "Could not sign in."
            }
        }
    }

    private fun setBusy(busy: Boolean) {
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        signInButton.isEnabled = !busy
    }

    private fun goToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
