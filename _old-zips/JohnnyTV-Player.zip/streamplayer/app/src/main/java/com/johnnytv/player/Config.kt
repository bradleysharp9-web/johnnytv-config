package com.johnnytv.player

/**
 * WHITE-LABEL CONFIG
 *
 * Everything you change per client build lives here (plus app_name in strings.xml,
 * the colours in colors.xml, the icons in res/mipmap-*, and applicationId in
 * app/build.gradle.kts).
 */
object Config {

    /** Pre-fill the portal address. Leave "" to make the user type it. */
    const val DEFAULT_SERVER: String = ""          // e.g. "http://your-portal.com:8080"

    /** true = hide the server field entirely and always use DEFAULT_SERVER. */
    const val LOCK_SERVER: Boolean = false

    /** Set BOTH (with DEFAULT_SERVER) for a fully pre-loaded build that skips the login screen. */
    const val PRESET_USERNAME: String = ""
    const val PRESET_PASSWORD: String = ""

    /** Live streams are tried in this order until one plays. */
    val LIVE_CONTAINERS: List<String> = listOf("m3u8", "ts")

    const val USER_AGENT: String = "JohnnyTV/1.0 (Android)"
}
